//
//  WorkoutEngineTests.swift
//  CindyTimerTests
//

import XCTest
@testable import CindyTimer

@MainActor
final class WorkoutEngineTests: XCTestCase {

    private func makeEngine() -> WorkoutEngine {
        PersistenceController.shared.clearActiveWorkout()
        let engine = WorkoutEngine(settings: AppSettingsStore())
        engine.configureNewWorkout(.cindy)
        return engine
    }

    func testCompletingFullRoundIncrementsRoundCounter() {
        let engine = makeEngine()
        engine.beginCountdown()
        engine.start()

        engine.completeCurrentExercise() // pull-ups -> push-ups
        engine.completeCurrentExercise() // push-ups -> air squats
        engine.completeCurrentExercise() // air squats -> round complete, back to pull-ups

        XCTAssertEqual(engine.completedRounds, 1)
        XCTAssertEqual(engine.currentExerciseIndex, 0)
        XCTAssertEqual(engine.currentReps, 0)
    }

    func testPartialRoundIsNotCountedAsCompleted() {
        let engine = makeEngine()
        engine.beginCountdown()
        engine.start()

        engine.completeCurrentExercise() // pull-ups done
        engine.completeCurrentExercise() // push-ups done
        // Air squats never completed for this round.
        engine.incrementRep()
        engine.incrementRep()
        engine.incrementRep()

        engine.endWorkoutEarly()

        XCTAssertEqual(engine.lastResult?.completedRounds, 0)
        // 5 pull-ups + 10 push-ups + 3 air squats = 18 partial reps.
        XCTAssertEqual(engine.lastResult?.partialRoundReps, 18)
    }

    func testEightFullRoundsPlusPartialMatchesSpecExample() {
        let engine = makeEngine()
        engine.beginCountdown()
        engine.start()

        for _ in 0..<8 {
            engine.completeCurrentExercise() // pull-ups
            engine.completeCurrentExercise() // push-ups
            engine.completeCurrentExercise() // air squats -> round complete
        }
        // Start a 9th round: pull-ups + push-ups done, 8 air squats in progress.
        engine.completeCurrentExercise() // pull-ups
        engine.completeCurrentExercise() // push-ups
        for _ in 0..<8 {
            engine.incrementRep()
        }

        engine.endWorkoutEarly()

        XCTAssertEqual(engine.lastResult?.completedRounds, 8)
        // 5 + 10 + 8 = 23, matching the spec's worked example exactly.
        XCTAssertEqual(engine.lastResult?.partialRoundReps, 23)
    }

    func testRepsCannotGoNegative() {
        let engine = makeEngine()
        engine.beginCountdown()
        engine.start()
        engine.decrementRep()
        engine.decrementRep()
        XCTAssertEqual(engine.currentReps, 0)
    }

    func testRepsCannotExceedExercisePrescription() {
        let engine = makeEngine()
        engine.beginCountdown()
        engine.start()
        for _ in 0..<20 {
            engine.incrementRep()
        }
        // Pull-Ups are prescribed at 5 reps in Cindy.
        XCTAssertEqual(engine.currentReps, 5)
    }

    func testRapidDoubleTapOnCompleteExerciseOnlyAdvancesOnce() {
        let engine = makeEngine()
        engine.beginCountdown()
        engine.start()

        engine.completeCurrentExercise()
        engine.completeCurrentExercise() // fired immediately after — should be debounced

        XCTAssertEqual(engine.currentExerciseIndex, 1) // advanced only once, to Push-Ups
    }

    func testEndWorkoutEarlyMarksResultAsNotCompleted() {
        let engine = makeEngine()
        engine.beginCountdown()
        engine.start()
        engine.incrementRep()
        engine.endWorkoutEarly()
        XCTAssertEqual(engine.lastResult?.isCompleted, false)
    }

    func testDiscardWithoutSavingLeavesNoResult() {
        let engine = makeEngine()
        engine.beginCountdown()
        engine.start()
        engine.incrementRep()
        engine.discardActiveWorkoutWithoutSaving()
        XCTAssertEqual(engine.state, .idle)
    }
}
