//
//  TimerEngineTests.swift
//  CindyTimerTests
//

import XCTest
@testable import CindyTimer

final class TimerEngineTests: XCTestCase {

    func testStartInitializesRemainingTime() {
        let engine = TimerEngine(timeLimitSeconds: 1200)
        engine.start(now: Date())
        XCTAssertEqual(engine.remainingSeconds, 1200)
        XCTAssertEqual(engine.elapsedSeconds, 0)
        XCTAssertTrue(engine.isRunning)
    }

    func testElapsedTimeComputedFromWallClockNotTicks() {
        let start = Date()
        let engine = TimerEngine(timeLimitSeconds: 1200)
        engine.start(now: start)
        // Simulate the app being backgrounded for 90 seconds with zero
        // timer ticks in between — this is exactly the scenario a naive
        // `timer -= 1` implementation would get wrong.
        let later = start.addingTimeInterval(90)
        engine.refreshFromSystemClock(now: later)
        XCTAssertEqual(engine.elapsedSeconds, 90)
        XCTAssertEqual(engine.remainingSeconds, 1110)
    }

    func testPauseFreezesElapsedTime() {
        let start = Date()
        let engine = TimerEngine(timeLimitSeconds: 1200)
        engine.start(now: start)
        let pauseMoment = start.addingTimeInterval(30)
        engine.pause(now: pauseMoment)

        // Time keeps passing in the real world, but the paused timer's
        // elapsed time must not move.
        let muchLater = pauseMoment.addingTimeInterval(500)
        engine.refreshFromSystemClock(now: muchLater)
        XCTAssertEqual(engine.elapsedSeconds, 30)
        XCTAssertFalse(engine.isRunning)
    }

    func testResumeExcludesPausedDuration() {
        let start = Date()
        let engine = TimerEngine(timeLimitSeconds: 1200)
        engine.start(now: start)
        engine.pause(now: start.addingTimeInterval(30))
        engine.resume(now: start.addingTimeInterval(90)) // paused for 60s
        let checkPoint = start.addingTimeInterval(100) // 10s after resume
        engine.refreshFromSystemClock(now: checkPoint)
        // 30s before pause + 10s after resume = 40s elapsed, not 100s.
        XCTAssertEqual(engine.elapsedSeconds, 40)
    }

    func testExpirationFiresExactlyOnceAtTimeLimit() {
        let start = Date()
        let engine = TimerEngine(timeLimitSeconds: 60)
        var expiredCount = 0
        engine.onExpired = { expiredCount += 1 }
        engine.start(now: start)
        engine.refreshFromSystemClock(now: start.addingTimeInterval(60))
        engine.refreshFromSystemClock(now: start.addingTimeInterval(65))
        engine.refreshFromSystemClock(now: start.addingTimeInterval(70))
        XCTAssertEqual(expiredCount, 1)
        XCTAssertEqual(engine.remainingSeconds, 0)
    }

    func testRestoreFromCrashRecoversElapsedTime() {
        let start = Date().addingTimeInterval(-120)
        let engine = TimerEngine(timeLimitSeconds: 1200)
        engine.restore(startDate: start, accumulatedPausedSeconds: 20, wasPaused: false, pauseStartDate: nil, now: Date())
        // ~120s real time minus 20s paused = ~100s elapsed.
        XCTAssertEqual(Double(engine.elapsedSeconds), 100, accuracy: 1)
    }

    func testRemainingNeverGoesNegative() {
        let start = Date()
        let engine = TimerEngine(timeLimitSeconds: 60)
        engine.start(now: start)
        engine.refreshFromSystemClock(now: start.addingTimeInterval(999))
        XCTAssertEqual(engine.remainingSeconds, 0)
        XCTAssertEqual(engine.elapsedSeconds, 60)
    }
}
