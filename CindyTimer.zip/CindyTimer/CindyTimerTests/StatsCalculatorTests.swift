//
//  StatsCalculatorTests.swift
//  CindyTimerTests
//

import XCTest
@testable import CindyTimer

final class StatsCalculatorTests: XCTestCase {

    private let calendar: Calendar = {
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = TimeZone(identifier: "UTC")!
        return cal
    }()

    private func day(_ offset: Int, from now: Date) -> Date {
        calendar.date(byAdding: .day, value: offset, to: now)!
    }

    func testStreakCountsConsecutiveDaysEndingToday() {
        let now = Date()
        let dates = [day(0, from: now), day(-1, from: now), day(-2, from: now)]
        let streak = StatsCalculator.streak(from: dates, now: now, calendar: calendar)
        XCTAssertEqual(streak.currentStreak, 3)
    }

    func testStreakStillCountsIfTodayNotYetDoneButYesterdayWas() {
        let now = Date()
        let dates = [day(-1, from: now), day(-2, from: now)]
        let streak = StatsCalculator.streak(from: dates, now: now, calendar: calendar)
        XCTAssertEqual(streak.currentStreak, 2)
    }

    func testStreakBreaksAfterAGapDay() {
        let now = Date()
        let dates = [day(0, from: now), day(-2, from: now)] // missing yesterday
        let streak = StatsCalculator.streak(from: dates, now: now, calendar: calendar)
        XCTAssertEqual(streak.currentStreak, 1)
    }

    func testBestStreakFindsLongestHistoricalRun() {
        let now = Date()
        // A 4-day run further in the past, then a gap, then a 1-day run today.
        let dates = [
            day(-30, from: now), day(-29, from: now), day(-28, from: now), day(-27, from: now),
            day(0, from: now)
        ]
        let streak = StatsCalculator.streak(from: dates, now: now, calendar: calendar)
        XCTAssertEqual(streak.bestStreak, 4)
        XCTAssertEqual(streak.currentStreak, 1)
    }

    func testEmptyHistoryHasZeroStreak() {
        let streak = StatsCalculator.streak(from: [])
        XCTAssertEqual(streak.currentStreak, 0)
        XCTAssertEqual(streak.bestStreak, 0)
    }

    func testPersonalBestComparesRoundsBeforePartialReps() {
        let higherRounds = WorkoutScore(rounds: 9, partialReps: 0)
        let higherReps = WorkoutScore(rounds: 8, partialReps: 40)
        XCTAssertTrue(higherRounds > higherReps)
    }

    func testIsPersonalBestTrueWhenNoPreviousSessions() {
        let candidate = WorkoutScore(rounds: 5, partialReps: 5)
        XCTAssertTrue(StatsCalculator.isPersonalBest(candidate: candidate, previousSessions: [], workoutName: "Cindy"))
    }
}
