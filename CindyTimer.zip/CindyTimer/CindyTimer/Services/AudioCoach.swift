//
//  AudioCoach.swift
//  Cindy Timer
//
//  Optional spoken cues ("Push-Ups", "One minute remaining"). Uses
//  AVSpeechSynthesizer with an ambient, mixable audio session category
//  so it never interrupts music, podcasts, or Spotify (Section 16).
//

import AVFoundation

final class AudioCoach {

    private let synthesizer = AVSpeechSynthesizer()
    private var didConfigureSession = false

    private var isVoiceEnabled: Bool {
        UserDefaults.standard.object(forKey: SettingsKey.voiceCoachEnabled) as? Bool ?? true
    }

    private var volume: Float {
        let stored = UserDefaults.standard.object(forKey: SettingsKey.voiceVolume) as? Double
        return Float(stored ?? 0.8)
    }

    func announce(_ text: String) {
        guard isVoiceEnabled else { return }
        configureSessionIfNeeded()

        let utterance = AVSpeechUtterance(string: text)
        utterance.rate = AVSpeechUtteranceDefaultSpeechRate
        utterance.volume = volume
        synthesizer.speak(utterance)
    }

    func announceTimeRemaining(seconds: Int) {
        guard isVoiceEnabled else { return }
        let phrase: String
        switch seconds {
        case 600: phrase = "10 minutes remaining"
        case 300: phrase = "5 minutes remaining"
        case 60: phrase = "1 minute remaining"
        case 30: phrase = "30 seconds"
        case 10: phrase = "10 seconds"
        case 5, 4, 3, 2, 1: phrase = "\(seconds)"
        case 0: phrase = "Time"
        default: return
        }
        announce(phrase)
    }

    private func configureSessionIfNeeded() {
        guard !didConfigureSession else { return }
        do {
            // .ambient mixes with other audio (music apps keep playing)
            // and respects the silent switch/Low Power Mode expectations.
            try AVAudioSession.sharedInstance().setCategory(.ambient, options: [.mixWithOthers])
            try AVAudioSession.sharedInstance().setActive(true, options: .notifyOthersOnDeactivation)
            didConfigureSession = true
        } catch {
            print("Cindy Timer: could not configure audio session: \(error)")
        }
    }
}
