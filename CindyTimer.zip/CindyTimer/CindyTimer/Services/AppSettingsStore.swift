//
//  AppSettingsStore.swift
//  Cindy Timer
//
//  All user preferences in one observable place, persisted to
//  UserDefaults (local only — see Section 22 on privacy).
//
//  Note: @AppStorage's automatic view-invalidation only works when the
//  property wrapper is declared directly inside a SwiftUI View. Declared
//  inside a plain ObservableObject class like this one, it would silently
//  fail to trigger `objectWillChange`, so bound Toggles/Pickers wouldn't
//  visually update even though the value saved correctly. To avoid that,
//  every setting here is a plain @Published property whose `didSet`
//  writes through to UserDefaults, with the initial value read back in
//  `init()`.
//

import SwiftUI
import Combine

enum SettingsKey {
    static let hapticsEnabled = "hapticsEnabled"
    static let voiceCoachEnabled = "voiceCoachEnabled"
    static let voiceVolume = "voiceVolume"
    static let soundsEnabled = "soundsEnabled"
    static let motivationalMessagesEnabled = "motivationalMessagesEnabled"
    static let motivationFrequency = "motivationFrequency"
    static let colorSchemePreference = "colorSchemePreference"
    static let accentColorChoice = "accentColorChoice"
    static let countdownEnabled = "countdownEnabled"
    static let workoutReminderEnabled = "workoutReminderEnabled"
    static let workoutReminderHour = "workoutReminderHour"
    static let workoutReminderMinute = "workoutReminderMinute"
    static let streakReminderEnabled = "streakReminderEnabled"
    static let hasCompletedOnboarding = "hasCompletedOnboarding"
}

enum ColorSchemePreference: String, CaseIterable, Identifiable {
    case system, light, dark
    var id: String { rawValue }

    var colorScheme: ColorScheme? {
        switch self {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }

    var displayName: String {
        switch self {
        case .system: return "System"
        case .light: return "Light"
        case .dark: return "Dark"
        }
    }
}

enum AccentColorChoice: String, CaseIterable, Identifiable {
    case ember, cobalt, mint, violet
    var id: String { rawValue }

    var color: Color {
        switch self {
        case .ember: return Color(red: 1.0, green: 0.34, blue: 0.2)
        case .cobalt: return Color(red: 0.18, green: 0.45, blue: 1.0)
        case .mint: return Color(red: 0.16, green: 0.85, blue: 0.6)
        case .violet: return Color(red: 0.58, green: 0.35, blue: 1.0)
        }
    }

    var displayName: String {
        switch self {
        case .ember: return "Ember"
        case .cobalt: return "Cobalt"
        case .mint: return "Mint"
        case .violet: return "Violet"
        }
    }
}

enum MotivationFrequency: String, CaseIterable, Identifiable {
    case low, standard, high
    var id: String { rawValue }
    var displayName: String {
        switch self {
        case .low: return "Rare"
        case .standard: return "Standard"
        case .high: return "Frequent"
        }
    }
}

final class AppSettingsStore: ObservableObject {

    private let defaults: UserDefaults

    @Published var hapticsEnabled: Bool { didSet { defaults.set(hapticsEnabled, forKey: SettingsKey.hapticsEnabled) } }
    @Published var voiceCoachEnabled: Bool { didSet { defaults.set(voiceCoachEnabled, forKey: SettingsKey.voiceCoachEnabled) } }
    @Published var voiceVolume: Double { didSet { defaults.set(voiceVolume, forKey: SettingsKey.voiceVolume) } }
    @Published var soundsEnabled: Bool { didSet { defaults.set(soundsEnabled, forKey: SettingsKey.soundsEnabled) } }
    @Published var motivationalMessagesEnabled: Bool { didSet { defaults.set(motivationalMessagesEnabled, forKey: SettingsKey.motivationalMessagesEnabled) } }
    @Published var countdownEnabled: Bool { didSet { defaults.set(countdownEnabled, forKey: SettingsKey.countdownEnabled) } }
    @Published var workoutReminderEnabled: Bool { didSet { defaults.set(workoutReminderEnabled, forKey: SettingsKey.workoutReminderEnabled) } }
    @Published var workoutReminderHour: Int { didSet { defaults.set(workoutReminderHour, forKey: SettingsKey.workoutReminderHour) } }
    @Published var workoutReminderMinute: Int { didSet { defaults.set(workoutReminderMinute, forKey: SettingsKey.workoutReminderMinute) } }
    @Published var streakReminderEnabled: Bool { didSet { defaults.set(streakReminderEnabled, forKey: SettingsKey.streakReminderEnabled) } }
    @Published var hasCompletedOnboarding: Bool { didSet { defaults.set(hasCompletedOnboarding, forKey: SettingsKey.hasCompletedOnboarding) } }

    @Published var motivationFrequency: MotivationFrequency {
        didSet { defaults.set(motivationFrequency.rawValue, forKey: SettingsKey.motivationFrequency) }
    }
    @Published var colorSchemePreference: ColorSchemePreference {
        didSet { defaults.set(colorSchemePreference.rawValue, forKey: SettingsKey.colorSchemePreference) }
    }
    @Published var accentColorChoice: AccentColorChoice {
        didSet { defaults.set(accentColorChoice.rawValue, forKey: SettingsKey.accentColorChoice) }
    }

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults

        hapticsEnabled = defaults.object(forKey: SettingsKey.hapticsEnabled) as? Bool ?? true
        voiceCoachEnabled = defaults.object(forKey: SettingsKey.voiceCoachEnabled) as? Bool ?? true
        voiceVolume = defaults.object(forKey: SettingsKey.voiceVolume) as? Double ?? 0.8
        soundsEnabled = defaults.object(forKey: SettingsKey.soundsEnabled) as? Bool ?? true
        motivationalMessagesEnabled = defaults.object(forKey: SettingsKey.motivationalMessagesEnabled) as? Bool ?? true
        countdownEnabled = defaults.object(forKey: SettingsKey.countdownEnabled) as? Bool ?? true
        workoutReminderEnabled = defaults.object(forKey: SettingsKey.workoutReminderEnabled) as? Bool ?? false
        workoutReminderHour = defaults.object(forKey: SettingsKey.workoutReminderHour) as? Int ?? 7
        workoutReminderMinute = defaults.object(forKey: SettingsKey.workoutReminderMinute) as? Int ?? 0
        streakReminderEnabled = defaults.object(forKey: SettingsKey.streakReminderEnabled) as? Bool ?? false
        hasCompletedOnboarding = defaults.object(forKey: SettingsKey.hasCompletedOnboarding) as? Bool ?? false

        motivationFrequency = MotivationFrequency(
            rawValue: defaults.string(forKey: SettingsKey.motivationFrequency) ?? ""
        ) ?? .standard
        colorSchemePreference = ColorSchemePreference(
            rawValue: defaults.string(forKey: SettingsKey.colorSchemePreference) ?? ""
        ) ?? .system
        accentColorChoice = AccentColorChoice(
            rawValue: defaults.string(forKey: SettingsKey.accentColorChoice) ?? ""
        ) ?? .ember
    }
}
