//
//  NotificationManager.swift
//  Cindy Timer
//
//  Optional, entirely local reminders ("Cindy is waiting"). No push
//  infrastructure, no server, nothing leaves the device (Section 22/31).
//

import UserNotifications

final class NotificationManager {

    static let shared = NotificationManager()
    private init() {}

    func requestAuthorizationIfNeeded(completion: @escaping (Bool) -> Void) {
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            switch settings.authorizationStatus {
            case .authorized, .provisional:
                completion(true)
            case .notDetermined:
                UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, _ in
                    completion(granted)
                }
            default:
                completion(false)
            }
        }
    }

    /// Schedules a single, gentle recurring reminder. Never stacks
    /// multiple reminders or sends more than one a day.
    func scheduleDailyReminder(hour: Int, minute: Int) {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: ["daily-cindy-reminder"])

        let content = UNMutableNotificationContent()
        content.title = "Cindy Timer"
        content.body = "Cindy is waiting. 20 minutes is all you need."
        content.sound = .default

        var dateComponents = DateComponents()
        dateComponents.hour = hour
        dateComponents.minute = minute

        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)
        let request = UNNotificationRequest(identifier: "daily-cindy-reminder", content: content, trigger: trigger)
        center.add(request)
    }

    func cancelDailyReminder() {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ["daily-cindy-reminder"])
    }

    /// A gentle, optional streak reminder — never phrased as a warning
    /// or as guilt (Section 9 / 31: "Ready to start again?", never "You failed").
    func scheduleStreakReminder(hour: Int, minute: Int) {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: ["streak-cindy-reminder"])

        let content = UNMutableNotificationContent()
        content.title = "Cindy Timer"
        content.body = "Ready to start again?"
        content.sound = .default

        var dateComponents = DateComponents()
        dateComponents.hour = hour
        dateComponents.minute = minute

        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)
        let request = UNNotificationRequest(identifier: "streak-cindy-reminder", content: content, trigger: trigger)
        center.add(request)
    }

    func cancelStreakReminder() {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ["streak-cindy-reminder"])
    }
}
