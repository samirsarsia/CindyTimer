//
//  HapticsManager.swift
//  Cindy Timer
//
//  Thin wrapper around UIKit's feedback generators. Centralized so
//  haptics can be globally disabled from Settings and so the rest of
//  the app never touches UIKit feedback types directly.
//

import UIKit

final class HapticsManager {

    private let lightGenerator = UIImpactFeedbackGenerator(style: .light)
    private let mediumGenerator = UIImpactFeedbackGenerator(style: .medium)
    private let heavyGenerator = UIImpactFeedbackGenerator(style: .heavy)
    private let notificationGenerator = UINotificationFeedbackGenerator()

    /// Reads live from UserDefaults via AppSettingsStore's key so this
    /// class doesn't need a reference to the store itself.
    private var isEnabled: Bool {
        UserDefaults.standard.object(forKey: SettingsKey.hapticsEnabled) as? Bool ?? true
    }

    func lightTap() {
        guard isEnabled else { return }
        lightGenerator.impactOccurred()
    }

    func mediumImpact() {
        guard isEnabled else { return }
        mediumGenerator.impactOccurred()
    }

    func roundComplete() {
        guard isEnabled else { return }
        heavyGenerator.impactOccurred()
    }

    func success() {
        guard isEnabled else { return }
        notificationGenerator.notificationOccurred(.success)
    }

    func countdownTick() {
        guard isEnabled else { return }
        lightGenerator.impactOccurred()
    }
}
