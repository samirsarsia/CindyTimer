//
//  WorkoutFlowView.swift
//  Cindy Timer
//
//  Wraps the countdown, active workout, rest, and completion screens
//  so the whole workout lives behind one full-screen presentation the
//  user can't accidentally swipe away from (Section 27).
//

import SwiftUI

struct WorkoutFlowView: View {
    @EnvironmentObject private var engine: WorkoutEngine

    var body: some View {
        Group {
            switch engine.state {
            case .countdown:
                PreWorkoutCountdownView()
            case .running, .paused:
                ActiveWorkoutView()
            case .resting:
                RestView()
            case .completed:
                EndOfWorkoutView()
            default:
                Color.clear
            }
        }
        .transition(.opacity)
    }
}
