//
//  RestView.swift
//  Cindy Timer
//
//  Optional rest period between rounds for custom workouts
//  (Section 17). Cindy itself has zero rest, so this only appears
//  for custom workouts that configure one.
//

import SwiftUI

struct RestView: View {
    @EnvironmentObject private var engine: WorkoutEngine
    @EnvironmentObject private var settings: AppSettingsStore

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 24) {
                Text("REST")
                    .font(.title.weight(.bold))
                    .foregroundStyle(.white.opacity(0.7))

                Text("\(engine.restRemainingSeconds)")
                    .font(.system(size: 90, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .contentTransition(.numericText(countsDown: true))
                    .animation(.easeInOut, value: engine.restRemainingSeconds)

                Text("Next: \(engine.currentExercise.reps) \(engine.currentExercise.name.uppercased())")
                    .font(.headline)
                    .foregroundStyle(settings.accentColorChoice.color)

                Button {
                    engine.skipRest()
                } label: {
                    Text("SKIP REST")
                        .font(.headline)
                        .padding(.horizontal, 28)
                        .padding(.vertical, 14)
                        .background(.white.opacity(0.12))
                        .foregroundStyle(.white)
                        .clipShape(Capsule())
                }
                .padding(.top, 12)
            }
        }
    }
}

#Preview {
    RestView()
        .environmentObject(WorkoutEngine(settings: AppSettingsStore()))
        .environmentObject(AppSettingsStore())
}
