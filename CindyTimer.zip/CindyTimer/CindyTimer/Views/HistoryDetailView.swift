//
//  HistoryDetailView.swift
//  Cindy Timer
//

import SwiftUI

struct HistoryDetailView: View {
    var session: WorkoutSession

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Text(session.startedAt.mediumDateString)
                    .font(.headline)
                    .foregroundStyle(.secondary)

                Text(session.score.displayString.uppercased())
                    .font(.system(size: 34, weight: .black, design: .rounded))

                if session.wasPersonalBest {
                    Text("PERSONAL BEST 🔥")
                        .font(.headline.weight(.bold))
                        .foregroundStyle(.orange)
                }

                VStack(spacing: 12) {
                    detailRow("Workout", session.workoutName)
                    detailRow("Time Cap", session.timeLimitSeconds.asClockString)
                    detailRow("Elapsed", session.elapsedSeconds.asClockString)
                    detailRow("Status", session.isCompleted ? "Completed" : "Ended early")
                    Divider()
                    detailRow("Pull-Ups", "\(session.pullUpsTotal)")
                    detailRow("Push-Ups", "\(session.pushUpsTotal)")
                    detailRow("Air Squats", "\(session.airSquatsTotal)")
                    Divider()
                    detailRow("Total Reps", "\(session.totalReps)")
                }
                .padding(20)
                .background(Color(.secondarySystemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 20))
                .padding(.horizontal)
            }
            .padding(.vertical, 24)
        }
        .navigationTitle("Workout Detail")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func detailRow(_ label: String, _ value: String) -> some View {
        HStack {
            Text(label).foregroundStyle(.secondary)
            Spacer()
            Text(value).fontWeight(.semibold)
        }
    }
}
