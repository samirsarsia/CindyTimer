//
//  SettingsView.swift
//  Cindy Timer
//

import SwiftUI
import SwiftData

struct SettingsView: View {
    @EnvironmentObject private var settings: AppSettingsStore
    @EnvironmentObject private var engine: WorkoutEngine
    @Environment(\.modelContext) private var modelContext
    @Query private var sessions: [WorkoutSession]

    @State private var showingDeleteConfirmation = false
    @State private var showingExportSheet = false
    @State private var exportURL: URL?

    var body: some View {
        NavigationStack {
            Form {
                Section("Workout") {
                    Toggle("Pre-workout countdown", isOn: $settings.countdownEnabled)
                }

                Section("Audio") {
                    Toggle("Sounds", isOn: $settings.soundsEnabled)
                    Toggle("Voice coaching", isOn: $settings.voiceCoachEnabled)
                    if settings.voiceCoachEnabled {
                        VStack(alignment: .leading) {
                            Text("Volume")
                            Slider(value: $settings.voiceVolume, in: 0...1)
                        }
                    }
                }

                Section("Haptics") {
                    Toggle("Haptics", isOn: $settings.hapticsEnabled)
                }

                Section("Motivation") {
                    Toggle("Motivational messages", isOn: $settings.motivationalMessagesEnabled)
                    if settings.motivationalMessagesEnabled {
                        Picker("Frequency", selection: Binding(
                            get: { settings.motivationFrequency },
                            set: { settings.motivationFrequency = $0 }
                        )) {
                            ForEach(MotivationFrequency.allCases) { freq in
                                Text(freq.displayName).tag(freq)
                            }
                        }
                    }
                }

                Section("Appearance") {
                    Picker("Theme", selection: Binding(
                        get: { settings.colorSchemePreference },
                        set: { settings.colorSchemePreference = $0 }
                    )) {
                        ForEach(ColorSchemePreference.allCases) { pref in
                            Text(pref.displayName).tag(pref)
                        }
                    }
                    Picker("Accent Color", selection: Binding(
                        get: { settings.accentColorChoice },
                        set: { settings.accentColorChoice = $0 }
                    )) {
                        ForEach(AccentColorChoice.allCases) { choice in
                            Label {
                                Text(choice.displayName)
                            } icon: {
                                Circle().fill(choice.color).frame(width: 16, height: 16)
                            }
                            .tag(choice)
                        }
                    }
                }

                Section("Notifications") {
                    Toggle("Workout reminders", isOn: $settings.workoutReminderEnabled)
                        .onChange(of: settings.workoutReminderEnabled) { _, enabled in
                            updateWorkoutReminder(enabled: enabled)
                        }
                    if settings.workoutReminderEnabled {
                        DatePicker(
                            "Reminder time",
                            selection: reminderTimeBinding,
                            displayedComponents: .hourAndMinute
                        )
                    }
                    Toggle("Streak reminders", isOn: $settings.streakReminderEnabled)
                        .onChange(of: settings.streakReminderEnabled) { _, enabled in
                            if enabled {
                                NotificationManager.shared.requestAuthorizationIfNeeded { granted in
                                    if granted {
                                        NotificationManager.shared.scheduleStreakReminder(hour: 18, minute: 0)
                                    }
                                }
                            } else {
                                NotificationManager.shared.cancelStreakReminder()
                            }
                        }
                }

                Section("Data") {
                    Button("Export Data") { exportData() }
                    Button("Delete All Data", role: .destructive) {
                        showingDeleteConfirmation = true
                    }
                }

                Section {
                    Text("Cindy Timer is fully private. Your workouts stay on this device — nothing is uploaded, tracked, or shared.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Settings")
            .confirmationDialog(
                "Delete all workout data?",
                isPresented: $showingDeleteConfirmation,
                titleVisibility: .visible
            ) {
                Button("Delete Everything", role: .destructive) { deleteAllData() }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("This permanently deletes your history, streaks, and personal records. This can't be undone.")
            }
            .sheet(isPresented: $showingExportSheet) {
                if let exportURL {
                    ShareSheet(activityItems: [exportURL])
                }
            }
        }
    }

    private var reminderTimeBinding: Binding<Date> {
        Binding(
            get: {
                Calendar.current.date(
                    bySettingHour: settings.workoutReminderHour,
                    minute: settings.workoutReminderMinute,
                    second: 0,
                    of: Date()
                ) ?? Date()
            },
            set: { newDate in
                let comps = Calendar.current.dateComponents([.hour, .minute], from: newDate)
                settings.workoutReminderHour = comps.hour ?? 7
                settings.workoutReminderMinute = comps.minute ?? 0
                updateWorkoutReminder(enabled: settings.workoutReminderEnabled)
            }
        )
    }

    private func updateWorkoutReminder(enabled: Bool) {
        guard enabled else {
            NotificationManager.shared.cancelDailyReminder()
            return
        }
        NotificationManager.shared.requestAuthorizationIfNeeded { granted in
            if granted {
                NotificationManager.shared.scheduleDailyReminder(
                    hour: settings.workoutReminderHour,
                    minute: settings.workoutReminderMinute
                )
            }
        }
    }

    private func deleteAllData() {
        for session in sessions {
            modelContext.delete(session)
        }
        try? modelContext.save()
        engine.discardActiveWorkoutWithoutSaving()
    }

    private func exportData() {
        let lines = sessions
            .sorted { $0.startedAt < $1.startedAt }
            .map { session in
                "\(session.startedAt.mediumDateString),\(session.workoutName),\(session.completedRounds),\(session.partialRoundReps),\(session.pullUpsTotal),\(session.pushUpsTotal),\(session.airSquatsTotal)"
            }
        let csv = "Date,Workout,Rounds,PartialReps,PullUps,PushUps,AirSquats\n" + lines.joined(separator: "\n")
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("cindy_timer_export.csv")
        try? csv.write(to: url, atomically: true, encoding: .utf8)
        exportURL = url
        showingExportSheet = true
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    var activityItems: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

#Preview {
    SettingsView()
        .environmentObject(AppSettingsStore())
        .environmentObject(WorkoutEngine(settings: AppSettingsStore()))
        .modelContainer(for: [WorkoutSession.self], inMemory: true)
}
