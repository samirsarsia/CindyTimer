//
//  EndOfWorkoutView.swift
//  Cindy Timer
//
//  Shows the final score, saves it to history exactly once, and offers
//  a friction-free way to finish up or go again (Section 29).
//

import SwiftUI
import SwiftData

struct EndOfWorkoutView: View {
    @EnvironmentObject private var engine: WorkoutEngine
    @EnvironmentObject private var settings: AppSettingsStore
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \WorkoutSession.startedAt, order: .reverse) private var sessions: [WorkoutSession]

    @State private var savedSession: WorkoutSession?
    @State private var showScore = false

    private var previousBestBeforeThis: WorkoutScore? {
        sessions
            .filter { $0.isCompleted && $0.workoutName == engine.lastResult?.workoutName && $0.id != savedSession?.id }
            .map { $0.score }
            .max()
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            if let result = engine.lastResult {
                VStack(spacing: 22) {
                    Spacer()

                    Text(result.isCompleted ? "TIME!" : "WORKOUT SAVED")
                        .font(.system(size: 30, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.7))

                    Text(result.score.displayString.uppercased())
                        .font(.system(size: 40, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                        .scaleEffect(showScore ? 1.0 : 0.6)
                        .opacity(showScore ? 1 : 0)
                        .animation(.spring(response: 0.5, dampingFraction: 0.65), value: showScore)

                    if savedSession?.wasPersonalBest == true {
                        Text("NEW PERSONAL BEST 🔥")
                            .font(.headline.weight(.heavy))
                            .foregroundStyle(settings.accentColorChoice.color)
                    }

                    VStack(spacing: 10) {
                        statRow("Pull-Ups", result.pullUps)
                        statRow("Push-Ups", result.pushUps)
                        statRow("Air Squats", result.airSquats)
                        if let previous = previousBestBeforeThis {
                            Divider().background(.white.opacity(0.2))
                            HStack {
                                Text("Previous best").foregroundStyle(.white.opacity(0.5))
                                Spacer()
                                Text(previous.displayString).foregroundStyle(.white.opacity(0.8))
                            }
                        }
                    }
                    .padding(20)
                    .background(.white.opacity(0.06))
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .padding(.horizontal, 24)

                    Text("You showed up. That matters.")
                        .font(.subheadline)
                        .foregroundStyle(.white.opacity(0.6))
                        .padding(.top, 4)
                        .opacity(settings.motivationalMessagesEnabled ? 1 : 0)

                    Spacer()

                    VStack(spacing: 12) {
                        Button {
                            engine.acknowledgeResultShown()
                            engine.configureNewWorkout(engine.definition)
                            if settings.countdownEnabled {
                                engine.beginCountdown()
                            } else {
                                engine.start()
                            }
                        } label: {
                            Text("WORK OUT AGAIN")
                                .font(.headline.weight(.heavy))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 18)
                                .background(.white.opacity(0.12))
                                .foregroundStyle(.white)
                                .clipShape(RoundedRectangle(cornerRadius: 20))
                        }

                        Button {
                            engine.acknowledgeResultShown()
                        } label: {
                            Text("DONE")
                                .font(.headline.weight(.heavy))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 18)
                                .background(settings.accentColorChoice.color)
                                .foregroundStyle(.white)
                                .clipShape(RoundedRectangle(cornerRadius: 20))
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, 24)
                }
            }
        }
        .onAppear {
            saveIfNeeded()
            withAnimation(.easeInOut.delay(0.2)) { showScore = true }
        }
    }

    private func statRow(_ label: String, _ value: Int) -> some View {
        HStack {
            Text(label).foregroundStyle(.white.opacity(0.6))
            Spacer()
            Text("\(value)").foregroundStyle(.white).fontWeight(.semibold)
        }
    }

    private func saveIfNeeded() {
        guard savedSession == nil, let result = engine.lastResult else { return }
        savedSession = WorkoutSaver.save(result, context: modelContext)
    }
}

#Preview {
    EndOfWorkoutView()
        .environmentObject(WorkoutEngine(settings: AppSettingsStore()))
        .environmentObject(AppSettingsStore())
        .modelContainer(for: [WorkoutSession.self], inMemory: true)
}
