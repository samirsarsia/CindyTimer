//
//  OnboardingView.swift
//  Cindy Timer
//
//  Deliberately short (Section 20). One welcome screen, one
//  permissions screen with plain-English explanations, done.
//

import SwiftUI

struct OnboardingView: View {
    @EnvironmentObject private var settings: AppSettingsStore
    @State private var step: Int = 0

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color.black, settings.accentColorChoice.color.opacity(0.35)],
                startPoint: .topLeading, endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            if step == 0 {
                welcomeStep
            } else {
                permissionsStep
            }
        }
        .foregroundStyle(.white)
    }

    private var welcomeStep: some View {
        VStack(spacing: 20) {
            Spacer()
            Text("CINDY")
                .font(.system(size: 56, weight: .black, design: .rounded))
                .tracking(2)
            Text("20 minutes. One round at a time.")
                .font(.title3.weight(.medium))
                .multilineTextAlignment(.center)
                .foregroundStyle(.white.opacity(0.85))
                .padding(.horizontal, 40)
            Spacer()
            Button {
                withAnimation { step = 1 }
            } label: {
                Text("LET'S GO")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 18)
                    .background(settings.accentColorChoice.color)
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
            }
            .padding(.horizontal, 32)
            .padding(.bottom, 40)
        }
    }

    private var permissionsStep: some View {
        VStack(spacing: 28) {
            Spacer()
            Text("A few quick things")
                .font(.title2.weight(.bold))

            VStack(alignment: .leading, spacing: 20) {
                permissionRow(
                    icon: "hand.tap.fill",
                    title: "Haptics",
                    detail: "A subtle buzz when you log a rep or finish an exercise."
                )
                permissionRow(
                    icon: "speaker.wave.2.fill",
                    title: "Voice coaching",
                    detail: "Optional spoken cues like \"Push-Ups\" and time callouts."
                )
                permissionRow(
                    icon: "sparkles",
                    title: "Motivational messages",
                    detail: "Short, occasional encouragement — never guilt."
                )
                permissionRow(
                    icon: "bell.fill",
                    title: "Reminders",
                    detail: "Optional. We'll ask separately, and only if you want them."
                )
            }
            .padding(.horizontal, 32)

            Spacer()

            Button {
                settings.hasCompletedOnboarding = true
            } label: {
                Text("CONTINUE")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 18)
                    .background(settings.accentColorChoice.color)
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
            }
            .padding(.horizontal, 32)
            .padding(.bottom, 40)
        }
    }

    private func permissionRow(icon: String, title: String, detail: String) -> some View {
        HStack(alignment: .top, spacing: 16) {
            Image(systemName: icon)
                .font(.title3)
                .frame(width: 32)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.headline)
                Text(detail).font(.subheadline).foregroundStyle(.white.opacity(0.7))
            }
        }
    }
}

#Preview {
    OnboardingView().environmentObject(AppSettingsStore())
}
