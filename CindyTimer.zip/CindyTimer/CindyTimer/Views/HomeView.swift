//
//  HomeView.swift
//  Cindy Timer
//
//  Answers "what do I do right now?" in under two seconds (Section 28).
//

import SwiftUI
import SwiftData

struct HomeView: View {
    @EnvironmentObject private var engine: WorkoutEngine
    @EnvironmentObject private var settings: AppSettingsStore
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \WorkoutSession.startedAt, order: .reverse) private var sessions: [WorkoutSession]
    @State private var showingCustomWorkouts = false

    private var stats: ProgressStats { StatsCalculator.progressStats(for: sessions) }
    private var completedToday: Bool {
        guard let last = stats.lastWorkoutDate else { return false }
        return Calendar.current.isDateInToday(last)
    }

    private var greeting: String {
        let hour = Calendar.current.component(.hour, from: Date())
        switch hour {
        case 0..<12: return "GOOD MORNING"
        case 12..<17: return "GOOD AFTERNOON"
        default: return "GOOD EVENING"
        }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 28) {
                    VStack(spacing: 6) {
                        Text(greeting)
                            .font(.headline)
                            .foregroundStyle(.secondary)
                        Text(completedToday ? "You showed up today. Nice work." : "READY FOR CINDY?")
                            .font(.system(size: 30, weight: .black, design: .rounded))
                            .multilineTextAlignment(.center)
                    }
                    .padding(.top, 12)

                    if stats.currentStreak > 0 {
                        HStack(spacing: 8) {
                            Text("🔥").font(.title2)
                            Text("\(stats.currentStreak) DAY STREAK")
                                .font(.headline.weight(.bold))
                        }
                        .padding(.horizontal, 20)
                        .padding(.vertical, 10)
                        .background(.orange.opacity(0.15))
                        .clipShape(Capsule())
                    }

                    if let pr = stats.personalBest {
                        VStack(spacing: 4) {
                            Text("PERSONAL BEST")
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(.secondary)
                            Text(pr.displayString.uppercased())
                                .font(.title2.weight(.heavy))
                        }
                        .padding(20)
                        .frame(maxWidth: .infinity)
                        .background(Color(.secondarySystemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .padding(.horizontal)
                    }

                    Button {
                        engine.configureNewWorkout(.cindy)
                        if settings.countdownEnabled {
                            engine.beginCountdown()
                        } else {
                            engine.start()
                        }
                    } label: {
                        Text("START CINDY")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 26)
                            .background(settings.accentColorChoice.color)
                            .foregroundStyle(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 24))
                            .shadow(color: settings.accentColorChoice.color.opacity(0.4), radius: 16, y: 8)
                    }
                    .padding(.horizontal)

                    if let last = sessions.first(where: { $0.isCompleted }) {
                        Text("Last workout: \(last.score.displayString)")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }

                    Button {
                        showingCustomWorkouts = true
                    } label: {
                        Text("Custom workouts")
                            .font(.subheadline.weight(.semibold))
                    }
                    .padding(.top, 8)

                    Text("Listen to your body. Stop if you feel unwell or unsafe.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 40)
                        .padding(.top, 20)
                }
                .padding(.bottom, 30)
            }
            .navigationTitle("")
            .navigationBarHidden(true)
            .sheet(isPresented: $showingCustomWorkouts) {
                CustomWorkoutListView()
            }
        }
    }
}

#Preview {
    HomeView()
        .environmentObject(WorkoutEngine(settings: AppSettingsStore()))
        .environmentObject(AppSettingsStore())
        .modelContainer(for: [WorkoutSession.self, CustomWorkout.self, CustomExercise.self], inMemory: true)
}
