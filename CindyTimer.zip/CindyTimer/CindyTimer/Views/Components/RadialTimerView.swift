//
//  RadialTimerView.swift
//  Cindy Timer
//
//  The visual centerpiece (Section 49). A radial ring sweeps down as
//  the workout time elapses, with the countdown and total time large
//  and legible in the middle — readable at a glance, from a distance,
//  mid-rep.
//

import SwiftUI

struct RadialTimerView: View {
    var remainingSeconds: Int
    var totalSeconds: Int
    var accentColor: Color
    var isFinalMinute: Bool

    private var progress: Double {
        guard totalSeconds > 0 else { return 0 }
        return Double(remainingSeconds) / Double(totalSeconds)
    }

    var body: some View {
        ZStack {
            Circle()
                .stroke(Color.white.opacity(0.08), lineWidth: 14)

            Circle()
                .trim(from: 0, to: progress)
                .stroke(
                    isFinalMinute ? Color.red.opacity(0.85) : accentColor,
                    style: StrokeStyle(lineWidth: 14, lineCap: .round)
                )
                .rotationEffect(.degrees(-90))
                .animation(.linear(duration: 0.9), value: progress)

            VStack(spacing: 4) {
                Text(remainingSeconds.asClockString)
                    .font(.system(size: 64, weight: .black, design: .rounded))
                    .monospacedDigit()
                    .foregroundStyle(.white)
                    .contentTransition(.numericText(countsDown: true))
                    .animation(.easeInOut(duration: 0.2), value: remainingSeconds)

                Text(totalSeconds.asClockString)
                    .font(.headline)
                    .foregroundStyle(.white.opacity(0.4))
                    .monospacedDigit()
            }
        }
        .padding(18)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Time remaining")
        .accessibilityValue(remainingSeconds.asClockString)
    }
}

#Preview {
    ZStack {
        Color.black.ignoresSafeArea()
        RadialTimerView(remainingSeconds: 742, totalSeconds: 1200, accentColor: .orange, isFinalMinute: false)
            .frame(width: 280, height: 280)
    }
}
