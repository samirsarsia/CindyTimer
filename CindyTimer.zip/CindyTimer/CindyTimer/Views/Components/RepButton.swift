//
//  RepButton.swift
//  Cindy Timer
//
//  Large, sweaty-hands-friendly rep buttons (Section 55).
//

import SwiftUI

struct RepButton: View {
    var symbol: String
    var accessibilityLabel: String
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 34, weight: .bold))
                .frame(maxWidth: .infinity)
                .frame(height: 84)
                .background(Color.white.opacity(0.1))
                .foregroundStyle(.white)
                .clipShape(RoundedRectangle(cornerRadius: 22))
        }
        .accessibilityLabel(accessibilityLabel)
    }
}
