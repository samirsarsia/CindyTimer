//
//  StatsView.swift
//  Cindy Timer
//
//  Simple, glanceable progress dashboard (Section 12). No chart
//  library dependency — a handful of bars is all this needs.
//

import SwiftUI
import SwiftData

struct StatsView: View {
    @Query(sort: \WorkoutSession.startedAt, order: .forward) private var sessions: [WorkoutSession]

    private var stats: ProgressStats { StatsCalculator.progressStats(for: sessions) }
    private var recentCompleted: [WorkoutSession] {
        Array(sessions.filter { $0.isCompleted }.suffix(10))
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 14) {
                    statCard("Total Workouts", "\(stats.totalWorkouts)")
                    statCard("Current Streak", "\(stats.currentStreak) 🔥")
                    statCard("Best Streak", "\(stats.bestStreak)")
                    statCard("Personal Best", stats.personalBest?.displayString ?? "—")
                    statCard("Total Rounds", "\(stats.totalRounds)")
                    statCard("Total Reps", "\(stats.totalReps)")
                    statCard("Avg Rounds", String(format: "%.1f", stats.averageRounds))
                    statCard("This Week", "\(stats.weeklyWorkouts)")
                }
                .padding(.horizontal)
                .padding(.top, 12)

                if !recentCompleted.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("RECENT ROUNDS")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.secondary)
                            .padding(.horizontal)

                        SimpleBarChart(sessions: recentCompleted)
                            .frame(height: 140)
                            .padding(.horizontal)
                    }
                    .padding(.top, 20)
                }
            }
            .navigationTitle("Progress")
        }
    }

    private func statCard(_ title: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title.uppercased())
                .font(.caption2.weight(.bold))
                .foregroundStyle(.secondary)
            Text(value)
                .font(.title2.weight(.heavy))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

private struct SimpleBarChart: View {
    var sessions: [WorkoutSession]

    private var maxRounds: Int { max(sessions.map { $0.completedRounds }.max() ?? 1, 1) }

    var body: some View {
        GeometryReader { geo in
            HStack(alignment: .bottom, spacing: 8) {
                ForEach(sessions) { session in
                    VStack(spacing: 4) {
                        RoundedRectangle(cornerRadius: 4)
                            .fill(session.wasPersonalBest ? Color.orange : Color.accentColor)
                            .frame(height: max(4, geo.size.height * CGFloat(session.completedRounds) / CGFloat(maxRounds)))
                        Text("\(session.completedRounds)")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                }
            }
            .frame(height: geo.size.height, alignment: .bottom)
        }
    }
}

#Preview {
    StatsView()
        .modelContainer(for: [WorkoutSession.self], inMemory: true)
}
