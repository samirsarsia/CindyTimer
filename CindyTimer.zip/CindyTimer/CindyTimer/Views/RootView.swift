//
//  RootView.swift
//  Cindy Timer
//
//  Top-level router. While a workout is active, the entire app is
//  replaced by the full-screen workout flow so the user can never
//  accidentally navigate away from it (Section 27).
//

import SwiftUI
import SwiftData

struct RootView: View {
    @EnvironmentObject private var engine: WorkoutEngine
    @EnvironmentObject private var settings: AppSettingsStore
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        Group {
            if !settings.hasCompletedOnboarding {
                OnboardingView()
            } else if engine.state == .idle {
                MainTabView()
            } else {
                WorkoutFlowView()
            }
        }
        .onChange(of: scenePhase) { _, newPhase in
            if newPhase == .active {
                engine.refreshFromForeground()
            }
        }
        .animation(.easeInOut(duration: 0.25), value: engine.state)
    }
}

struct MainTabView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem { Label("Home", systemImage: "flame.fill") }

            HistoryView()
                .tabItem { Label("History", systemImage: "clock.arrow.circlepath") }

            StatsView()
                .tabItem { Label("Progress", systemImage: "chart.bar.fill") }

            SettingsView()
                .tabItem { Label("Settings", systemImage: "gearshape.fill") }
        }
    }
}
