//
//  ActiveWorkoutView.swift
//  Cindy Timer
//
//  The screen the user spends 95% of their workout looking at.
//  Answers "what do I do right now?" without any navigation
//  (Section 2 / 3 / 42).
//

import SwiftUI

struct ActiveWorkoutView: View {
    @EnvironmentObject private var engine: WorkoutEngine
    @EnvironmentObject private var settings: AppSettingsStore

    @State private var showingEndConfirmation = false
    @State private var repBounce = false

    private var isFinalMinute: Bool { engine.timerEngine.remainingSeconds <= 60 }
    private var isPaused: Bool { engine.state == .paused }

    /// A short, occasional line of encouragement. Deliberately sparse —
    /// only near-end time callouts and one mid-workout nudge after the
    /// second round — so it never becomes noise (Section 8).
    private var motivationalMessage: String? {
        let remaining = engine.timerEngine.remainingSeconds
        if let timeMessage = MotivationLibrary.timeRemainingMessage(seconds: remaining) {
            return timeMessage
        }
        if engine.completedRounds == 2 && engine.currentExerciseIndex == 0 && engine.currentReps == 0 {
            return MotivationLibrary.midWorkout.randomElement()
        }
        return nil
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 0) {
                topBar

                Spacer(minLength: 8)

                RadialTimerView(
                    remainingSeconds: engine.timerEngine.remainingSeconds,
                    totalSeconds: engine.timerEngine.timeLimitSeconds,
                    accentColor: settings.accentColorChoice.color,
                    isFinalMinute: isFinalMinute
                )
                .frame(width: 240, height: 240)

                Text("ROUND \(engine.completedRounds + 1)")
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.white.opacity(0.6))
                    .padding(.top, 8)

                Spacer(minLength: 8)

                VStack(spacing: 6) {
                    Text(engine.currentExercise.name.uppercased())
                        .font(.system(size: 34, weight: .black, design: .rounded))
                        .foregroundStyle(.white)

                    Text("\(engine.currentReps) / \(engine.currentExercise.reps)")
                        .font(.system(size: 24, weight: .bold, design: .rounded))
                        .foregroundStyle(settings.accentColorChoice.color)
                        .scaleEffect(repBounce ? 1.15 : 1.0)

                    ProgressBar(progress: Double(engine.currentReps) / Double(max(engine.currentExercise.reps, 1)),
                                color: settings.accentColorChoice.color)
                        .frame(height: 10)
                        .padding(.horizontal, 50)
                        .padding(.top, 4)
                }

                Text("NEXT: \(engine.nextExercise.reps) \(engine.nextExercise.name.uppercased())")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.4))
                    .padding(.top, 10)

                Text(engine.progressDisplayString)
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.35))
                    .padding(.top, 2)

                if settings.motivationalMessagesEnabled, let message = motivationalMessage {
                    Text(message.uppercased())
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(settings.accentColorChoice.color)
                        .padding(.top, 10)
                        .transition(.opacity)
                        .id(message)
                }

                Spacer(minLength: 12)

                HStack(spacing: 14) {
                    RepButton(symbol: "minus", accessibilityLabel: "Remove one rep") {
                        engine.decrementRep()
                    }
                    .disabled(isPaused)
                    .opacity(isPaused ? 0.4 : 1.0)

                    RepButton(symbol: "plus", accessibilityLabel: "Add one rep") {
                        engine.incrementRep()
                        bounce()
                    }
                    .disabled(isPaused)
                    .opacity(isPaused ? 0.4 : 1.0)
                }
                .padding(.horizontal, 20)

                Button {
                    engine.completeCurrentExercise()
                } label: {
                    Text("COMPLETE EXERCISE")
                        .font(.headline.weight(.heavy))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 20)
                        .background(settings.accentColorChoice.color)
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 22))
                }
                .disabled(isPaused)
                .opacity(isPaused ? 0.4 : 1.0)
                .padding(.horizontal, 20)
                .padding(.top, 14)
                .padding(.bottom, 20)
            }

            if isPaused {
                pausedOverlay
            }
        }
        .confirmationDialog(
            "End workout?",
            isPresented: $showingEndConfirmation,
            titleVisibility: .visible
        ) {
            Button("End Workout", role: .destructive) {
                engine.endWorkoutEarly()
            }
            Button("Keep Going", role: .cancel) {}
        } message: {
            Text("Your current progress will be saved.")
        }
    }

    private var topBar: some View {
        HStack {
            Button {
                showingEndConfirmation = true
            } label: {
                Image(systemName: "xmark")
                    .font(.headline)
                    .foregroundStyle(.white.opacity(0.6))
                    .frame(width: 44, height: 44)
            }
            .accessibilityLabel("End workout")

            Spacer()

            Button {
                if isPaused {
                    engine.resume()
                } else {
                    engine.pause()
                }
            } label: {
                Image(systemName: isPaused ? "play.fill" : "pause.fill")
                    .font(.headline)
                    .foregroundStyle(.white.opacity(0.6))
                    .frame(width: 44, height: 44)
            }
            .accessibilityLabel(isPaused ? "Resume" : "Pause")
        }
        .padding(.horizontal, 12)
        .padding(.top, 8)
    }

    private var pausedOverlay: some View {
        VStack(spacing: 20) {
            Text("PAUSED")
                .font(.system(size: 36, weight: .black, design: .rounded))
                .foregroundStyle(.white)
            Button {
                engine.resume()
            } label: {
                Text("RESUME")
                    .font(.headline.weight(.heavy))
                    .padding(.horizontal, 40)
                    .padding(.vertical, 16)
                    .background(settings.accentColorChoice.color)
                    .foregroundStyle(.white)
                    .clipShape(Capsule())
            }
        }
        .padding(40)
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 28))
        .padding(40)
    }

    private func bounce() {
        withAnimation(.spring(response: 0.2, dampingFraction: 0.4)) { repBounce = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
            withAnimation(.spring(response: 0.2, dampingFraction: 0.6)) { repBounce = false }
        }
    }
}

private struct ProgressBar: View {
    var progress: Double
    var color: Color

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                Capsule().fill(Color.white.opacity(0.1))
                Capsule()
                    .fill(color)
                    .frame(width: geo.size.width * min(max(progress, 0), 1))
                    .animation(.easeOut(duration: 0.2), value: progress)
            }
        }
    }
}

#Preview {
    ActiveWorkoutView()
        .environmentObject(WorkoutEngine(settings: AppSettingsStore()))
        .environmentObject(AppSettingsStore())
}
