//
//  PreWorkoutCountdownView.swift
//  Cindy Timer
//
//  "GET READY" -> 3 -> 2 -> 1 -> "GO!" then hands off to the engine's
//  running state (Section 14).
//

import SwiftUI

struct PreWorkoutCountdownView: View {
    @EnvironmentObject private var engine: WorkoutEngine
    @EnvironmentObject private var settings: AppSettingsStore

    @State private var phase: Phase = .getReady
    private let haptics = HapticsManager()

    enum Phase: Equatable {
        case getReady, three, two, one, go
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            Text(label)
                .font(.system(size: phase == .getReady ? 44 : 96, weight: .black, design: .rounded))
                .foregroundStyle(.white)
                .contentTransition(.numericText())
                .scaleEffect(scale)
                .animation(.spring(response: 0.35, dampingFraction: 0.6), value: phase)
        }
        .onAppear { runSequence() }
        .accessibilityElement(children: .combine)
        .accessibilityLabel(label)
    }

    private var label: String {
        switch phase {
        case .getReady: return "GET READY"
        case .three: return "3"
        case .two: return "2"
        case .one: return "1"
        case .go: return "GO!"
        }
    }

    private var scale: CGFloat {
        phase == .getReady ? 1.0 : 1.1
    }

    private func runSequence() {
        let steps: [(Phase, TimeInterval)] = [
            (.getReady, 1.0),
            (.three, 1.0),
            (.two, 1.0),
            (.one, 1.0),
            (.go, 0.6)
        ]
        var delay: TimeInterval = 0
        for (index, step) in steps.enumerated() {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                phase = step.0
                if settings.hapticsEnabled, index > 0 {
                    haptics.countdownTick()
                }
                if step.0 == .go {
                    DispatchQueue.main.asyncAfter(deadline: .now() + step.1) {
                        engine.start()
                    }
                }
            }
            delay += step.1
        }
    }
}

#Preview {
    PreWorkoutCountdownView()
        .environmentObject(WorkoutEngine(settings: AppSettingsStore()))
        .environmentObject(AppSettingsStore())
}
