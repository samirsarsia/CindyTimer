//
//  CustomWorkoutListView.swift
//  Cindy Timer
//
//  Section 13: custom workout mode. Kept intentionally simple —
//  a name, a time cap, an exercise list, AMRAP or fixed rounds,
//  and optional rest.
//

import SwiftUI
import SwiftData

struct CustomWorkoutListView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext
    @EnvironmentObject private var engine: WorkoutEngine
    @EnvironmentObject private var settings: AppSettingsStore
    @Query(sort: \CustomWorkout.createdAt, order: .reverse) private var workouts: [CustomWorkout]

    @State private var showingEditor = false

    var body: some View {
        NavigationStack {
            Group {
                if workouts.isEmpty {
                    ContentUnavailableView(
                        "No custom workouts",
                        systemImage: "slider.horizontal.3",
                        description: Text("Create your own AMRAP or fixed-round workout.")
                    )
                } else {
                    List {
                        Button {
                            engine.configureNewWorkout(.cindy)
                            startWorkout()
                        } label: {
                            Label("Cindy (default)", systemImage: "flame.fill")
                        }

                        ForEach(workouts) { workout in
                            Button {
                                engine.configureNewWorkout(workout.asDefinition())
                                startWorkout()
                            } label: {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(workout.name).font(.headline)
                                    Text(summary(for: workout))
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                            .foregroundStyle(.primary)
                        }
                        .onDelete(perform: delete)
                    }
                }
            }
            .navigationTitle("Custom Workouts")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showingEditor = true
                    } label: {
                        Image(systemName: "plus")
                    }
                }
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Close") { dismiss() }
                }
            }
            .sheet(isPresented: $showingEditor) {
                CustomWorkoutEditorView()
            }
        }
    }

    private func summary(for workout: CustomWorkout) -> String {
        let roundsText = workout.fixedRoundCount.map { "\($0) rounds" } ?? "AMRAP"
        let minutes = workout.timeLimitSeconds / 60
        let exerciseNames = workout.exercises.sorted { $0.order < $1.order }.map { "\($0.reps) \($0.name)" }
        return "\(minutes) min · \(roundsText) · " + exerciseNames.joined(separator: ", ")
    }

    private func startWorkout() {
        dismiss()
        if settings.countdownEnabled {
            engine.beginCountdown()
        } else {
            engine.start()
        }
    }

    private func delete(at offsets: IndexSet) {
        for index in offsets {
            modelContext.delete(workouts[index])
        }
        try? modelContext.save()
    }
}

struct CustomWorkoutEditorView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext

    @State private var name: String = ""
    @State private var minutes: Int = 10
    @State private var isAMRAP: Bool = true
    @State private var fixedRounds: Int = 3
    @State private var restSeconds: Int = 0
    @State private var exerciseRows: [ExerciseRowInput] = [
        ExerciseRowInput(name: "Push-Ups", reps: 10),
        ExerciseRowInput(name: "Air Squats", reps: 15)
    ]

    struct ExerciseRowInput: Identifiable {
        var id = UUID()
        var name: String
        var reps: Int
    }

    private var isValid: Bool {
        !name.trimmingCharacters(in: .whitespaces).isEmpty
            && minutes > 0
            && !exerciseRows.isEmpty
            && exerciseRows.allSatisfy { !$0.name.trimmingCharacters(in: .whitespaces).isEmpty && $0.reps > 0 }
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Workout Name") {
                    TextField("e.g. 10-Minute AMRAP", text: $name)
                }

                Section("Time Limit") {
                    Stepper("\(minutes) minutes", value: $minutes, in: 1...60)
                }

                Section("Format") {
                    Toggle("AMRAP (as many rounds as possible)", isOn: $isAMRAP)
                    if !isAMRAP {
                        Stepper("\(fixedRounds) rounds", value: $fixedRounds, in: 1...50)
                    }
                    Stepper("Rest between rounds: \(restSeconds)s", value: $restSeconds, in: 0...180, step: 15)
                }

                Section("Exercises") {
                    ForEach($exerciseRows) { $row in
                        HStack {
                            TextField("Exercise", text: $row.name)
                            Divider()
                            Stepper("\(row.reps)", value: $row.reps, in: 1...200)
                                .fixedSize()
                        }
                    }
                    .onDelete { exerciseRows.remove(atOffsets: $0) }

                    Button {
                        exerciseRows.append(ExerciseRowInput(name: "", reps: 10))
                    } label: {
                        Label("Add Exercise", systemImage: "plus")
                    }
                }
            }
            .navigationTitle("New Workout")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") { save() }.disabled(!isValid)
                }
            }
        }
    }

    private func save() {
        let workout = CustomWorkout(
            name: name.trimmingCharacters(in: .whitespaces),
            timeLimitSeconds: minutes * 60,
            fixedRoundCount: isAMRAP ? nil : fixedRounds,
            restSecondsBetweenRounds: restSeconds
        )
        for (index, row) in exerciseRows.enumerated() {
            let exercise = CustomExercise(
                name: row.name.trimmingCharacters(in: .whitespaces),
                reps: max(1, row.reps),
                order: index
            )
            exercise.workout = workout
            workout.exercises.append(exercise)
        }
        modelContext.insert(workout)
        try? modelContext.save()
        dismiss()
    }
}

#Preview {
    CustomWorkoutListView()
        .environmentObject(WorkoutEngine(settings: AppSettingsStore()))
        .environmentObject(AppSettingsStore())
        .modelContainer(for: [CustomWorkout.self, CustomExercise.self], inMemory: true)
}
