//
//  WorkoutDefinition.swift
//  Cindy Timer
//
//  Plain value types describing "what a workout is" — independent of
//  persistence. The built-in Cindy workout and any custom workout both
//  get converted into one of these before the engine runs them.
//

import Foundation

/// One exercise in the repeating sequence, e.g. "Pull-Ups" x 5.
struct ExerciseStep: Identifiable, Equatable, Codable {
    var id = UUID()
    var name: String
    var reps: Int
}

/// A complete workout definition: the sequence of exercises that
/// repeats, the time limit, and whether it's AMRAP or a fixed number
/// of rounds.
struct WorkoutDefinition: Equatable, Codable {
    var name: String
    var timeLimitSeconds: Int
    var exercises: [ExerciseStep]
    /// nil = AMRAP. A value = stop after this many rounds even if time remains.
    var fixedRoundCount: Int?
    var restSecondsBetweenRounds: Int

    static let cindy = WorkoutDefinition(
        name: "Cindy",
        timeLimitSeconds: 20 * 60,
        exercises: [
            ExerciseStep(name: "Pull-Ups", reps: 5),
            ExerciseStep(name: "Push-Ups", reps: 10),
            ExerciseStep(name: "Air Squats", reps: 15)
        ],
        fixedRoundCount: nil,
        restSecondsBetweenRounds: 0
    )
}
