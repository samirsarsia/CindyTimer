//
//  WorkoutModels.swift
//  Cindy Timer
//
//  SwiftData models for persisted workout history, custom workouts,
//  and the exercises inside them. These are the single source of
//  truth for anything that needs to survive an app relaunch.
//

import Foundation
import SwiftData

/// A single completed (or in-progress-then-saved) workout result.
/// One WorkoutSession is created per workout attempt.
@Model
final class WorkoutSession {
    /// Stable identity used to prevent duplicate history rows being
    /// created for the same workout (see Guardrail 7).
    @Attribute(.unique) var id: UUID

    var workoutName: String
    var startedAt: Date
    var completedAt: Date?
    var timeLimitSeconds: Int
    var elapsedSeconds: Int

    /// Number of fully completed rounds (a round only counts once every
    /// exercise in the sequence has been completed in full).
    var completedRounds: Int

    /// Reps completed in the partial round after the last full round.
    var partialRoundReps: Int

    /// True only if the workout ran to completion (time expired), not
    /// if it was cancelled early via "End Workout".
    var isCompleted: Bool

    var pullUpsTotal: Int
    var pushUpsTotal: Int
    var airSquatsTotal: Int

    var wasPersonalBest: Bool

    init(
        id: UUID = UUID(),
        workoutName: String,
        startedAt: Date,
        completedAt: Date? = nil,
        timeLimitSeconds: Int,
        elapsedSeconds: Int,
        completedRounds: Int,
        partialRoundReps: Int,
        isCompleted: Bool,
        pullUpsTotal: Int,
        pushUpsTotal: Int,
        airSquatsTotal: Int,
        wasPersonalBest: Bool = false
    ) {
        self.id = id
        self.workoutName = workoutName
        self.startedAt = startedAt
        self.completedAt = completedAt
        self.timeLimitSeconds = timeLimitSeconds
        self.elapsedSeconds = elapsedSeconds
        self.completedRounds = completedRounds
        self.partialRoundReps = partialRoundReps
        self.isCompleted = isCompleted
        self.pullUpsTotal = pullUpsTotal
        self.pushUpsTotal = pushUpsTotal
        self.airSquatsTotal = airSquatsTotal
        self.wasPersonalBest = wasPersonalBest
    }

    /// Total reps across every exercise, used for stats screens.
    var totalReps: Int { pullUpsTotal + pushUpsTotal + airSquatsTotal }

    /// The comparable "score" used for personal-best ranking:
    /// rounds first, then leftover reps as the tiebreaker.
    var score: WorkoutScore { WorkoutScore(rounds: completedRounds, partialReps: partialRoundReps) }
}

/// A lightweight, comparable representation of a Cindy-style result,
/// e.g. "9 rounds + 5 reps". Rounds always outrank partial reps.
struct WorkoutScore: Comparable, Equatable {
    var rounds: Int
    var partialReps: Int

    static func < (lhs: WorkoutScore, rhs: WorkoutScore) -> Bool {
        if lhs.rounds != rhs.rounds { return lhs.rounds < rhs.rounds }
        return lhs.partialReps < rhs.partialReps
    }

    var displayString: String {
        "\(rounds) Round\(rounds == 1 ? "" : "s") + \(partialReps) Rep\(partialReps == 1 ? "" : "s")"
    }
}

/// A user-created workout template (custom AMRAP or fixed-rounds workout).
@Model
final class CustomWorkout {
    @Attribute(.unique) var id: UUID
    var name: String
    var timeLimitSeconds: Int
    /// nil means AMRAP (as many rounds as possible in the time limit).
    var fixedRoundCount: Int?
    var restSecondsBetweenRounds: Int
    var createdAt: Date

    @Relationship(deleteRule: .cascade, inverse: \CustomExercise.workout)
    var exercises: [CustomExercise] = []

    init(
        id: UUID = UUID(),
        name: String,
        timeLimitSeconds: Int,
        fixedRoundCount: Int? = nil,
        restSecondsBetweenRounds: Int = 0,
        createdAt: Date = Date()
    ) {
        self.id = id
        self.name = name
        self.timeLimitSeconds = timeLimitSeconds
        self.fixedRoundCount = fixedRoundCount
        self.restSecondsBetweenRounds = restSecondsBetweenRounds
        self.createdAt = createdAt
    }

    /// Converts this saved template into the runtime definition the
    /// workout engine understands, sorted into the correct order.
    func asDefinition() -> WorkoutDefinition {
        let steps = exercises
            .sorted { $0.order < $1.order }
            .map { ExerciseStep(name: $0.name, reps: $0.reps) }
        return WorkoutDefinition(
            name: name,
            timeLimitSeconds: timeLimitSeconds,
            exercises: steps,
            fixedRoundCount: fixedRoundCount,
            restSecondsBetweenRounds: restSecondsBetweenRounds
        )
    }
}

/// One exercise step inside a custom workout, in sequence order.
@Model
final class CustomExercise {
    @Attribute(.unique) var id: UUID
    var name: String
    var reps: Int
    var order: Int
    var workout: CustomWorkout?

    init(id: UUID = UUID(), name: String, reps: Int, order: Int) {
        self.id = id
        self.name = name
        self.reps = reps
        self.order = order
    }
}
