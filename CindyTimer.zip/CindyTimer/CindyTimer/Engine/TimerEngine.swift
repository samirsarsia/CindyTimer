//
//  TimerEngine.swift
//  Cindy Timer
//
//  A wall-clock based countdown. It never simply decrements a number
//  every second — instead it always recomputes elapsed time from
//  `Date()` minus a fixed start time minus accumulated paused time.
//  That means backgrounding, locking the phone, phone calls, or the
//  UI freezing for a moment can never make the timer drift, because
//  the *next* time it's asked "how much time is left", it re-derives
//  the truth from real timestamps rather than trusting its last tick.
//

import Foundation
import Combine

/// Publishes elapsed/remaining time once per second while running,
/// but is always safe to query on demand (e.g. right after the app
/// returns to the foreground) for the true elapsed time.
final class TimerEngine: ObservableObject {

    @Published private(set) var elapsedSeconds: Int = 0
    @Published private(set) var remainingSeconds: Int
    @Published private(set) var isRunning: Bool = false
    @Published private(set) var isExpired: Bool = false

    let timeLimitSeconds: Int

    /// The instant the workout was first started (never changes on pause/resume).
    private(set) var startDate: Date?
    /// The instant the current pause began, if paused.
    private var pauseStartDate: Date?
    /// Total seconds spent paused so far, accumulated across every pause.
    private var accumulatedPausedSeconds: TimeInterval = 0

    private var displayTimer: Timer?

    /// Called exactly once, the moment remaining time reaches zero.
    var onExpired: (() -> Void)?

    init(timeLimitSeconds: Int) {
        self.timeLimitSeconds = timeLimitSeconds
        self.remainingSeconds = timeLimitSeconds
    }

    /// Starts the timer fresh. Safe to call only from the idle state.
    func start(now: Date = Date()) {
        guard startDate == nil else { return }
        startDate = now
        accumulatedPausedSeconds = 0
        pauseStartDate = nil
        isRunning = true
        isExpired = false
        recalculate(now: now)
        beginDisplayTimer()
    }

    /// Restores a previously-running timer from persisted state, e.g.
    /// after a crash or force-quit (Guardrail 4 / 5).
    func restore(startDate: Date, accumulatedPausedSeconds: TimeInterval, wasPaused: Bool, pauseStartDate: Date?, now: Date = Date()) {
        self.startDate = startDate
        self.accumulatedPausedSeconds = accumulatedPausedSeconds
        self.pauseStartDate = wasPaused ? (pauseStartDate ?? now) : nil
        self.isRunning = !wasPaused
        recalculate(now: now)
        if isRunning {
            beginDisplayTimer()
        }
    }

    func pause(now: Date = Date()) {
        guard isRunning, pauseStartDate == nil else { return }
        pauseStartDate = now
        isRunning = false
        stopDisplayTimer()
        recalculate(now: now)
    }

    func resume(now: Date = Date()) {
        guard !isRunning, let pauseStart = pauseStartDate, startDate != nil else { return }
        accumulatedPausedSeconds += now.timeIntervalSince(pauseStart)
        pauseStartDate = nil
        isRunning = true
        recalculate(now: now)
        beginDisplayTimer()
    }

    /// Call whenever the app returns to the foreground to immediately
    /// snap the displayed time to the true elapsed time.
    func refreshFromSystemClock(now: Date = Date()) {
        recalculate(now: now)
    }

    func stopAndReset() {
        stopDisplayTimer()
        startDate = nil
        pauseStartDate = nil
        accumulatedPausedSeconds = 0
        elapsedSeconds = 0
        remainingSeconds = timeLimitSeconds
        isRunning = false
        isExpired = false
    }

    // MARK: - Persistence helpers (used by WorkoutEngine to save recovery state)

    var currentPauseStartDate: Date? { pauseStartDate }
    var currentAccumulatedPausedSeconds: TimeInterval { accumulatedPausedSeconds }

    // MARK: - Private

    private func beginDisplayTimer() {
        stopDisplayTimer()
        // The display timer only drives UI refresh cadence; the actual
        // remaining-time math is always recomputed from real dates, so
        // a missed or delayed tick (e.g. while scrolling) can't cause drift.
        let timer = Timer(timeInterval: 1.0, repeats: true) { [weak self] _ in
            self?.recalculate(now: Date())
        }
        RunLoop.main.add(timer, forMode: .common)
        displayTimer = timer
    }

    private func stopDisplayTimer() {
        displayTimer?.invalidate()
        displayTimer = nil
    }

    private func recalculate(now: Date) {
        guard let startDate else { return }
        let pausedSoFar = accumulatedPausedSeconds + (pauseStartDate.map { now.timeIntervalSince($0) } ?? 0)
        let rawElapsed = now.timeIntervalSince(startDate) - pausedSoFar
        let clampedElapsed = max(0, min(Double(timeLimitSeconds), rawElapsed))
        let newElapsed = Int(clampedElapsed.rounded(.down))

        elapsedSeconds = newElapsed
        remainingSeconds = max(0, timeLimitSeconds - newElapsed)

        if newElapsed >= timeLimitSeconds && !isExpired {
            isExpired = true
            isRunning = false
            stopDisplayTimer()
            onExpired?()
        }
    }

    deinit {
        displayTimer?.invalidate()
    }
}
