//
//  WorkoutEngine.swift
//  Cindy Timer
//
//  The single source of truth for an active workout. Every screen
//  reads from this object and every workout-changing action (rep taps,
//  pause, resume, end) goes through it — no view is allowed to mutate
//  workout state on its own. This is what makes double-taps, background
//  interruptions, and crash-recovery safe to reason about in one place.
//

import Foundation
import Combine

enum WorkoutState: Equatable {
    case idle
    case countdown
    case running
    case paused
    case resting
    case completed
    case cancelled
    case recovering
}

@MainActor
final class WorkoutEngine: ObservableObject {

    // MARK: - Published state read by the UI

    @Published private(set) var state: WorkoutState = .idle
    @Published private(set) var definition: WorkoutDefinition = .cindy
    @Published private(set) var currentExerciseIndex: Int = 0
    @Published private(set) var currentReps: Int = 0
    @Published private(set) var completedRounds: Int = 0
    @Published private(set) var log: [ExerciseCompletionRecord] = []
    @Published private(set) var lastResult: WorkoutResult?
    @Published private(set) var restRemainingSeconds: Int = 0

    @Published var timerEngine: TimerEngine = TimerEngine(timeLimitSeconds: WorkoutDefinition.cindy.timeLimitSeconds)

    // MARK: - Dependencies

    private let settings: AppSettingsStore
    private let haptics = HapticsManager()
    private let audioCoach = AudioCoach()
    private var restTimer: Timer?
    private var startDate: Date?
    private var sessionID: UUID = UUID()

    // Guardrail 6: ignore taps that arrive faster than this after the
    // previous exercise-completion tap, to stop accidental double-advance.
    private let minimumTapInterval: TimeInterval = 0.35
    private var lastAdvanceTap: Date = .distantPast

    init(settings: AppSettingsStore) {
        self.settings = settings
        restoreIfPossible()
    }

    // MARK: - Derived values for the UI

    var currentExercise: ExerciseStep { definition.exercises[currentExerciseIndex] }

    var nextExercise: ExerciseStep {
        let nextIndex = (currentExerciseIndex + 1) % definition.exercises.count
        return definition.exercises[nextIndex]
    }

    var totalRepsSoFar: Int {
        completedRounds * definition.exercises.reduce(0) { $0 + $1.reps }
            + definition.exercises[0..<currentExerciseIndex].reduce(0) { $0 + $1.reps }
            + currentReps
    }

    var progressDisplayString: String {
        "\(completedRounds) ROUND\(completedRounds == 1 ? "" : "S") + \(currentRoundPartialReps) REPS"
    }

    /// Reps completed within the round currently in progress (not counting
    /// full completed rounds), used for the "2 ROUNDS + 7 REPS" display.
    private var currentRoundPartialReps: Int {
        definition.exercises[0..<currentExerciseIndex].reduce(0) { $0 + $1.reps } + currentReps
    }

    // MARK: - Lifecycle actions

    func configureNewWorkout(_ definition: WorkoutDefinition) {
        guard state == .idle || state == .completed || state == .cancelled else { return }
        self.definition = definition
        self.timerEngine = TimerEngine(timeLimitSeconds: definition.timeLimitSeconds)
        currentExerciseIndex = 0
        currentReps = 0
        completedRounds = 0
        log = []
        lastResult = nil
        state = .idle
        PersistenceController.shared.clearActiveWorkout()
    }

    func beginCountdown() {
        guard state == .idle else { return }
        state = .countdown
    }

    func start() {
        guard state == .countdown || state == .idle else { return }
        sessionID = UUID()
        startDate = Date()
        state = .running
        timerEngine.start(now: startDate!)
        timerEngine.onExpired = { [weak self] in
            Task { @MainActor in self?.finishWorkout(completedByTimer: true) }
        }
        audioCoach.announce(currentExercise.name)
        persistActiveState()
    }

    func pause() {
        guard state == .running else { return }
        state = .paused
        timerEngine.pause()
        persistActiveState()
    }

    func resume() {
        guard state == .paused else { return }
        state = .running
        timerEngine.resume()
        persistActiveState()
    }

    /// Called by the app when it returns to the foreground so the UI
    /// snaps to the true elapsed time immediately.
    func refreshFromForeground() {
        guard state == .running else { return }
        timerEngine.refreshFromSystemClock()
        if timerEngine.isExpired {
            finishWorkout(completedByTimer: true)
        }
    }

    /// User-initiated early end. Requires confirmation in the UI before
    /// this is called (Guardrail 2).
    func endWorkoutEarly() {
        guard state == .running || state == .paused else { return }
        timerEngine.pause()
        finishWorkout(completedByTimer: false)
    }

    // MARK: - Rep tracking

    func incrementRep() {
        guard state == .running else { return }
        currentReps = min(currentReps + 1, currentExercise.reps)
        haptics.lightTap()
        persistActiveState()
    }

    func decrementRep() {
        guard state == .running else { return }
        // Guardrail 3: never allow negative reps.
        currentReps = max(currentReps - 1, 0)
        haptics.lightTap()
        persistActiveState()
    }

    /// Advances to the next exercise (or completes a round). Debounced
    /// against accidental rapid double taps (Guardrail 6).
    func completeCurrentExercise() {
        guard state == .running else { return }
        let now = Date()
        guard now.timeIntervalSince(lastAdvanceTap) > minimumTapInterval else { return }
        lastAdvanceTap = now

        let completedExercise = currentExercise
        log.append(ExerciseCompletionRecord(
            exerciseName: completedExercise.name,
            repsCompleted: completedExercise.reps,
            roundIndex: completedRounds,
            timestamp: now
        ))

        haptics.mediumImpact()

        let isLastExerciseInSequence = currentExerciseIndex == definition.exercises.count - 1

        if isLastExerciseInSequence {
            completedRounds += 1
            currentExerciseIndex = 0
            currentReps = 0
            haptics.roundComplete()

            if let fixedRounds = definition.fixedRoundCount, completedRounds >= fixedRounds {
                finishWorkout(completedByTimer: false)
                return
            }

            if definition.restSecondsBetweenRounds > 0 {
                beginRest()
                return
            }
        } else {
            currentExerciseIndex += 1
            currentReps = 0
        }

        audioCoach.announce(currentExercise.name)
        persistActiveState()
    }

    // MARK: - Rest periods

    private func beginRest() {
        state = .resting
        restRemainingSeconds = definition.restSecondsBetweenRounds
        restTimer?.invalidate()
        restTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.tickRest() }
        }
        persistActiveState()
    }

    private func tickRest() {
        restRemainingSeconds -= 1
        if restRemainingSeconds <= 0 {
            skipRest()
        }
    }

    func skipRest() {
        guard state == .resting else { return }
        restTimer?.invalidate()
        restTimer = nil
        restRemainingSeconds = 0
        state = .running
        audioCoach.announce(currentExercise.name)
        persistActiveState()
    }

    // MARK: - Completion

    private func finishWorkout(completedByTimer: Bool) {
        restTimer?.invalidate()
        restTimer = nil
        timerEngine.pause()

        let pullUps = totalCompletedReps(for: "Pull-Ups")
        let pushUps = totalCompletedReps(for: "Push-Ups")
        let squats = totalCompletedReps(for: "Air Squats")

        let result = WorkoutResult(
            sessionID: sessionID,
            workoutName: definition.name,
            startedAt: startDate ?? Date(),
            completedAt: Date(),
            timeLimitSeconds: definition.timeLimitSeconds,
            elapsedSeconds: timerEngine.elapsedSeconds,
            completedRounds: completedRounds,
            partialRoundReps: currentRoundPartialReps,
            isCompleted: completedByTimer,
            pullUps: pullUps,
            pushUps: pushUps,
            airSquats: squats
        )

        lastResult = result
        state = .completed
        PersistenceController.shared.clearActiveWorkout()
    }

    private func totalCompletedReps(for exerciseName: String) -> Int {
        let fromLog = log.filter { $0.exerciseName == exerciseName }.reduce(0) { $0 + $1.repsCompleted }
        // Include in-progress reps toward the exercise currently being done,
        // so a workout that ends mid-exercise still counts partial reps.
        let inProgress = (currentExercise.name == exerciseName) ? currentReps : 0
        return fromLog + inProgress
    }

    func acknowledgeResultShown() {
        state = .idle
    }

    // MARK: - Crash / force-quit recovery (Guardrail 4)

    private func persistActiveState() {
        guard let startDate else { return }
        let snapshot = ActiveWorkoutSnapshot(
            sessionID: sessionID,
            definition: definition,
            currentExerciseIndex: currentExerciseIndex,
            currentReps: currentReps,
            completedRounds: completedRounds,
            log: log,
            startDate: startDate,
            accumulatedPausedSeconds: timerEngine.currentAccumulatedPausedSeconds,
            pauseStartDate: timerEngine.currentPauseStartDate,
            wasPaused: state == .paused,
            state: state,
            restRemainingSeconds: restRemainingSeconds
        )
        PersistenceController.shared.saveActiveWorkout(snapshot)
    }

    private func restoreIfPossible() {
        guard let snapshot = PersistenceController.shared.loadActiveWorkout() else { return }
        definition = snapshot.definition
        currentExerciseIndex = snapshot.currentExerciseIndex
        currentReps = snapshot.currentReps
        completedRounds = snapshot.completedRounds
        log = snapshot.log
        sessionID = snapshot.sessionID
        startDate = snapshot.startDate
        restRemainingSeconds = snapshot.restRemainingSeconds

        timerEngine = TimerEngine(timeLimitSeconds: snapshot.definition.timeLimitSeconds)
        timerEngine.restore(
            startDate: snapshot.startDate,
            accumulatedPausedSeconds: snapshot.accumulatedPausedSeconds,
            wasPaused: snapshot.wasPaused,
            pauseStartDate: snapshot.pauseStartDate
        )
        timerEngine.onExpired = { [weak self] in
            Task { @MainActor in self?.finishWorkout(completedByTimer: true) }
        }

        if timerEngine.isExpired {
            finishWorkout(completedByTimer: true)
        } else {
            state = snapshot.wasPaused ? .paused : .running
        }
    }

    /// Explicitly discards any in-progress workout without saving a
    /// history record — used only for the "End Workout" confirmation
    /// screen, and for user-initiated data resets.
    func discardActiveWorkoutWithoutSaving() {
        restTimer?.invalidate()
        restTimer = nil
        timerEngine.stopAndReset()
        state = .idle
        PersistenceController.shared.clearActiveWorkout()
    }
}

/// A single "exercise completed" event during the active workout.
struct ExerciseCompletionRecord: Identifiable, Equatable, Codable {
    var id: UUID = UUID()
    var exerciseName: String
    var repsCompleted: Int
    var roundIndex: Int
    var timestamp: Date
}

/// The final outcome of a workout, ready to be shown on the
/// end-of-workout screen and saved to history.
struct WorkoutResult: Equatable {
    var sessionID: UUID
    var workoutName: String
    var startedAt: Date
    var completedAt: Date
    var timeLimitSeconds: Int
    var elapsedSeconds: Int
    var completedRounds: Int
    var partialRoundReps: Int
    var isCompleted: Bool
    var pullUps: Int
    var pushUps: Int
    var airSquats: Int

    var score: WorkoutScore { WorkoutScore(rounds: completedRounds, partialReps: partialRoundReps) }
}
