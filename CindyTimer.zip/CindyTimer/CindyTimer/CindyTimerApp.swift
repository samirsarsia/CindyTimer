//
//  CindyTimerApp.swift
//  Cindy Timer
//
//  App entry point. Wires up the SwiftData model container and
//  injects the shared services (haptics, audio, notifications)
//  used throughout the app.
//

import SwiftUI
import SwiftData

@main
struct CindyTimerApp: App {

    let modelContainer: ModelContainer

    @StateObject private var workoutEngine: WorkoutEngine
    @StateObject private var appSettings: AppSettingsStore

    init() {
        let schema = Schema([
            WorkoutSession.self,
            CustomWorkout.self,
            CustomExercise.self
        ])
        do {
            let configuration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)
            modelContainer = try ModelContainer(for: schema, configurations: [configuration])
        } catch {
            // If the on-disk store can't be opened (rare, e.g. corrupted store),
            // fall back to an in-memory container so the app still launches
            // instead of crashing. The user will see an error banner offering
            // to reset data rather than losing use of the app entirely.
            let fallbackConfig = ModelConfiguration(schema: schema, isStoredInMemoryOnly: true)
            modelContainer = try! ModelContainer(for: schema, configurations: [fallbackConfig])
        }

        let settings = AppSettingsStore()
        _appSettings = StateObject(wrappedValue: settings)
        _workoutEngine = StateObject(wrappedValue: WorkoutEngine(settings: settings))
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(workoutEngine)
                .environmentObject(appSettings)
                .modelContainer(modelContainer)
                .preferredColorScheme(appSettings.colorSchemePreference.colorScheme)
        }
    }
}
