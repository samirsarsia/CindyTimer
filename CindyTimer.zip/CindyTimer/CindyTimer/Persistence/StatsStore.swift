//
//  StatsStore.swift
//  Cindy Timer
//
//  Turns a raw list of WorkoutSession history rows into the numbers
//  the Home, Progress, and end-of-workout screens actually show:
//  streaks, personal bests, weekly/monthly counts, and averages.
//
//  Kept as pure functions over an array of sessions wherever possible
//  so this logic can be unit tested without touching SwiftData at all.
//

import Foundation
import SwiftData

struct StreakInfo {
    var currentStreak: Int
    var bestStreak: Int
}

struct ProgressStats {
    var totalWorkouts: Int
    var currentStreak: Int
    var bestStreak: Int
    var personalBest: WorkoutScore?
    var totalRounds: Int
    var totalReps: Int
    var averageRounds: Double
    var weeklyWorkouts: Int
    var monthlyWorkouts: Int
    var lastWorkoutDate: Date?
}

enum StatsCalculator {

    /// Computes the daily streak from completed workout dates.
    /// A day counts if at least one completed workout happened on it.
    /// Missing "today" does not break the streak until the day has
    /// fully passed — the app should never guilt someone mid-day.
    static func streak(from completedDates: [Date], now: Date = Date(), calendar: Calendar = .current) -> StreakInfo {
        let days = Set(completedDates.map { calendar.startOfDay(for: $0) }).sorted(by: >)
        guard !days.isEmpty else { return StreakInfo(currentStreak: 0, bestStreak: 0) }

        let today = calendar.startOfDay(for: now)

        // Current streak: walk backwards from today (or yesterday, if
        // today has no workout yet) counting consecutive days.
        var current = 0
        var cursor = today
        if !days.contains(today) {
            // Today not done yet — that's fine, check if yesterday keeps
            // the streak alive rather than zeroing it out prematurely.
            cursor = calendar.date(byAdding: .day, value: -1, to: today) ?? today
        }
        while days.contains(cursor) {
            current += 1
            cursor = calendar.date(byAdding: .day, value: -1, to: cursor) ?? cursor
        }

        // Best streak ever: scan the full sorted set for the longest
        // consecutive run.
        let ascending = days.sorted()
        var best = 0
        var run = 0
        var previous: Date?
        for day in ascending {
            if let previous, let expected = calendar.date(byAdding: .day, value: 1, to: previous), calendar.isDate(expected, inSameDayAs: day) {
                run += 1
            } else {
                run = 1
            }
            best = max(best, run)
            previous = day
        }

        return StreakInfo(currentStreak: current, bestStreak: max(best, current))
    }

    static func progressStats(for sessions: [WorkoutSession], now: Date = Date(), calendar: Calendar = .current) -> ProgressStats {
        let completed = sessions.filter { $0.isCompleted }
        let dates = completed.map { $0.completedAt ?? $0.startedAt }
        let streakInfo = streak(from: dates, now: now, calendar: calendar)

        let best = completed.map { $0.score }.max()
        let totalRounds = completed.reduce(0) { $0 + $1.completedRounds }
        let totalReps = completed.reduce(0) { $0 + $1.totalReps }
        let average = completed.isEmpty ? 0 : Double(totalRounds) / Double(completed.count)

        let weekAgo = calendar.date(byAdding: .day, value: -7, to: now) ?? now
        let monthAgo = calendar.date(byAdding: .day, value: -30, to: now) ?? now
        let weekly = completed.filter { ($0.completedAt ?? $0.startedAt) >= weekAgo }.count
        let monthly = completed.filter { ($0.completedAt ?? $0.startedAt) >= monthAgo }.count

        return ProgressStats(
            totalWorkouts: completed.count,
            currentStreak: streakInfo.currentStreak,
            bestStreak: streakInfo.bestStreak,
            personalBest: best,
            totalRounds: totalRounds,
            totalReps: totalReps,
            averageRounds: average,
            weeklyWorkouts: weekly,
            monthlyWorkouts: monthly,
            lastWorkoutDate: dates.max()
        )
    }

    /// True if `candidate` beats every previous completed score for the
    /// same workout name.
    static func isPersonalBest(candidate: WorkoutScore, previousSessions: [WorkoutSession], workoutName: String) -> Bool {
        let previousBest = previousSessions
            .filter { $0.isCompleted && $0.workoutName == workoutName }
            .map { $0.score }
            .max()
        guard let previousBest else { return true }
        return candidate > previousBest
    }
}

@MainActor
enum WorkoutSaver {
    /// Saves a finished workout result to SwiftData exactly once.
    /// Guardrail 7 (no duplicate history records): callers should only
    /// invoke this a single time per `WorkoutResult`, and the unique
    /// `sessionID` stamped onto the row lets a defensive check skip a
    /// second insert if it's ever called twice for the same session.
    static func save(_ result: WorkoutResult, context: ModelContext) -> WorkoutSession? {
        let sessionID = result.sessionID
        let existingFetch = FetchDescriptor<WorkoutSession>(
            predicate: #Predicate { $0.id == sessionID }
        )
        if let existing = try? context.fetch(existingFetch), !existing.isEmpty {
            return existing.first
        }

        let allSessions = (try? context.fetch(FetchDescriptor<WorkoutSession>())) ?? []
        let isPR = StatsCalculator.isPersonalBest(candidate: result.score, previousSessions: allSessions, workoutName: result.workoutName)

        let session = WorkoutSession(
            id: sessionID,
            workoutName: result.workoutName,
            startedAt: result.startedAt,
            completedAt: result.completedAt,
            timeLimitSeconds: result.timeLimitSeconds,
            elapsedSeconds: result.elapsedSeconds,
            completedRounds: result.completedRounds,
            partialRoundReps: result.partialRoundReps,
            isCompleted: result.isCompleted,
            pullUpsTotal: result.pullUps,
            pushUpsTotal: result.pushUps,
            airSquatsTotal: result.airSquats,
            wasPersonalBest: isPR
        )
        context.insert(session)
        do {
            try context.save()
        } catch {
            print("Cindy Timer: failed to save workout session: \(error)")
            return nil
        }
        return session
    }
}
