//
//  PersistenceController.swift
//  Cindy Timer
//
//  Handles the small amount of state that needs to survive a crash or
//  force-quit mid-workout (Guardrail 4). This is deliberately separate
//  from the SwiftData history store: it's a tiny, fast, always-available
//  snapshot written to disk after every meaningful workout event.
//

import Foundation

/// Everything needed to fully reconstruct an in-progress workout.
struct ActiveWorkoutSnapshot: Codable {
    var sessionID: UUID
    var definition: WorkoutDefinition
    var currentExerciseIndex: Int
    var currentReps: Int
    var completedRounds: Int
    var log: [ExerciseCompletionRecord]
    var startDate: Date
    var accumulatedPausedSeconds: TimeInterval
    var pauseStartDate: Date?
    var wasPaused: Bool
    var state: WorkoutState
    var restRemainingSeconds: Int
}

// WorkoutState needs to round-trip through JSON for the snapshot above.
extension WorkoutState: Codable {}

final class PersistenceController {
    static let shared = PersistenceController()

    private let snapshotURL: URL

    private init() {
        let directory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        snapshotURL = directory.appendingPathComponent("active_workout.json")
    }

    func saveActiveWorkout(_ snapshot: ActiveWorkoutSnapshot) {
        do {
            let data = try JSONEncoder().encode(snapshot)
            try data.write(to: snapshotURL, options: .atomic)
        } catch {
            // Best-effort: if this single write fails, the in-memory workout
            // is still fine. We simply won't be able to recover it after a
            // crash. We deliberately don't surface this to the user mid-set.
            print("Cindy Timer: failed to persist active workout snapshot: \(error)")
        }
    }

    func loadActiveWorkout() -> ActiveWorkoutSnapshot? {
        guard let data = try? Data(contentsOf: snapshotURL) else { return nil }
        return try? JSONDecoder().decode(ActiveWorkoutSnapshot.self, from: data)
    }

    func clearActiveWorkout() {
        try? FileManager.default.removeItem(at: snapshotURL)
    }
}
