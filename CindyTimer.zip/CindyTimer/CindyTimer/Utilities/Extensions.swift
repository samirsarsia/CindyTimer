//
//  Extensions.swift
//  Cindy Timer
//

import Foundation

extension Int {
    /// Formats seconds as "19:42" style mm:ss for the countdown display.
    var asClockString: String {
        let minutes = self / 60
        let seconds = self % 60
        return String(format: "%d:%02d", minutes, seconds)
    }
}

extension Date {
    var mediumDateString: String {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        formatter.timeStyle = .none
        return formatter.string(from: self)
    }
}

/// Centralized, low-frequency motivational copy (Section 8 / 30).
/// Deliberately short and never guilt-based.
enum MotivationLibrary {
    static let preWorkout = [
        "20 minutes. One round at a time.",
        "Let's get to work."
    ]

    static let midWorkout = [
        "Keep moving.",
        "You're already ahead of yesterday.",
        "One more round."
    ]

    static func timeRemainingMessage(seconds: Int) -> String? {
        switch seconds {
        case 120: return "You have 2 minutes. Finish strong."
        case 60: return "ONE. MORE. ROUND."
        default: return nil
        }
    }

    static let postWorkout = "You showed up. That matters."
    static let personalBest = "NEW PERSONAL BEST 🔥"
    static let missedDayPrompt = "Ready to start again?"
}
